const http = require('http');
//const weather = require('./weather.json');
const server = http.createServer();
const Promise = require("bluebird");

var fs = Promise.promisifyAll(require("fs"));

Promise.try(() => {
    return fs.readFileSync('weather.json')
 
}).then(weatherArray => {
    console.log('inside' + weatherArray);

    server.on('request', (request, response) => {

        response.end(`Hello ` + weatherArray);
    })
}).then(() => {

    server.listen(3133, (err) => {
        if (err) {
            return console.log('something bad happened', err);
        }

        console.log(`server is listening on http://localhost:3133`);
    })
}).catch((err) => {
    console.log(err);
})

/*let weatherArray = [] ;
 weatherArray = fs.readFile('weather.json', function (err, data) {
        if (err) {
           return console.error(err);
        }
        console.log('here' , JSON.parse(data));
        console.log(JSON.stringify(JSON.parse(data)));
        return JSON.stringify(JSON.parse(data));
     });
     console.log('outside' + weatherArray);
server.on('request', (request, response) => {
    response.end('Hello' + JSON.stringify(weatherArray));
   
});
*/

//can set the port to listen on
/*const port = 3000;

const requestHandler = (request, response) => {  
  console.log(request.url);
  //end method ends execution and sends message to browser
  response.end('Hello Node.js Server!');
}
*/


//start server and listen on port, hostname(optional),
//it runs until ended. Ctrl+C or Ctrl+break 
/*server.listen(3131, (err) => {  
  if (err) {
    return console.log('something bad happened', err);
  }

  console.log(`Server running at http://localhost:3131}/`);
})*/