function math(one, two,three){
    return one + (two * three);
}

console.log(math(53, 61, 67));