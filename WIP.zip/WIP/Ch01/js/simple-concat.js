function Person(fname, lname) {
    this.fname = fname;
    this.lname = lname;
    this.getFullName = function(){
        return `${fname} ${lname}`
    }
}

let person1 = new Person("first", "last");
console.log(person1.getFullName());