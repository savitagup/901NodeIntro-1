const express = require('express');
let router = express.Router();
const moment = require('moment');
const Promise = require("bluebird");
const studentArray = require('./../student');
var fs = Promise.promisifyAll(require("fs"));

/*router.get('/', (req,res) => {
    res.send('Hello world, this is first page');
});
*/
router.get('/', (req,res) => {
    res.render('index', {
        students : studentArray
    });
});

router.get('/about', (req,res) => {
    //res.send('Hello world, this is from about page');
    res.render("about");
});

router.get('/class', (req,res) => {
    //res.send('Welcome to class page');
    res.render("class", {
        students: studentArray
    });
});

router.get('/weather', (req,res) => {
    
    Promise.try(() => {
        return fs.readFileSync('weather.json')
    
    }).then(weatherArray => {
        console.log('inside' + weatherArray);
        res.end(`Hello ` + weatherArray);
        
    }).catch((err) => {
        console.log(err);
    })

});

module.exports = router;