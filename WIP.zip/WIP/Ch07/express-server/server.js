const path = require('path');
const express = require('express');
const config = require('./config.json');
const routes = require('./routes/index');
let app = express();

app.listen(config.port,(() => {
    console.log(`Server running at http://localhost:3000}/`);
}));

app.set('views', path.join(__dirname,'views'));
app.set('view engine', 'pug');
app.use(express.static(path.join(__dirname, 'public')));

app.use(routes);


