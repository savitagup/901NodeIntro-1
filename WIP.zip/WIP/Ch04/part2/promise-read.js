var Promise = require('bluebird');
var fs = Promise.promisifyAll(require("fs"));

//console.log("Going to read into existing file");
/*Promise.try(() => {
    return fs.readFileAsync('input.txt');
}).then((data) => {
    console.log( data.toString());
}).catch((err) => {
    console.log(err);
})
*/

Promise.try(() => {
    return fs.readFileAsync('run-on.txt');
}).then((data) => {
    var str = data.toString().split('.');
    for(i =0 ;i<str.length; i++){
        str[i] = str[i].replace('.', '.\n');
    }
    
    /*
    str.forEach(element => {
       element = element.replace('.', '.\n');
    });*/
    console.log(str);
    fs.writeFileAsync('run-on.txt', str.toString());//.replace('.', '.\n'));
    //console.log(str.length)
   // console.log( data.toString());
}).then(() => {
    return fs.readFileAsync('run-on.txt');
}).then((data) => {
    console.log(data.toString());
}).catch((err) => {
    console.log(err);
})


//console.log('End of program file');