const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));
/*
Promise.try(() => {
	return db.schema.createTable("customer", (table) => {
		table.increments("id").primary();
		table.text("firstName");
		table.text("lastName");
		table.text("email");
	});
}).then(() => {
	console.log("Done!");
}).finally(() => {
	db.destroy();
});


Promise.try(() => {
	return db("customer").insert([{
		firstName: "Joe",
		lastName: "Bloggs",
		email: 'Joe_bloggs@email.com'
	}, {
		firstName: "Joe",
		lastName: "Smith",
		email: "joe_smith@email.com"
	}]);
}).then(() => {
	console.log("Done!");
}).finally(() => {
	db.destroy();
});
*/
Promise.try(() => {
	return db("customer");
}).then((customers) => {
    console.log('all the customers', customers)
	console.log("Done!");
}).finally(() => {
	db.destroy();
});
