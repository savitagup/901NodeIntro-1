var moment = require('moment');
console.log(moment().format('MM-DD-YYYY'));
console.log(moment("01-01-2011", "MM-DD-YYYY").fromNow());