module.exports = class Band{
    constructor(name, members){
        this.name = name;
        this.members = members;
    }

    getBandName(){
        return name;
    }

    getBandMembers(){
        return members;
    }

    getMemberCount(){
        return this.members.length;
    }

    hasMember(fName){
        return this.members.includes(fName);
    }
}

