module.exports = class ShapeAreaCalculator{
    
    getAreaOfCircle(radius){
        return 3.14 * radius * radius;
    }

    getAreaOfSquare(length){
        return  length * length;
    }

    getAreaOfRectangle(length, width){
        return length * width;
    }
}