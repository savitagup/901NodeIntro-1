const add = require('./add.js');
const Calculator = require ('./calculator.js');
const Band = require ('./constructor-band.js');
const ShapeAreaCalculator = require ('./shape-area-calculator.js');

console.log('5 + 7 = ',add(5,7));
const myCalc = new Calculator();
const myAreaCalc = new ShapeAreaCalculator();
console.log('using calculator : 5 + 7 = ',myCalc.add(5,7));

const beatles = new Band('The Beatles', ['John', 'Paul', 'George', 'Ringo']);
console.log(beatles.getMemberCount());
console.log(' Ringo is part of Beatles' , beatles.hasMember('Ringo'));
console.log(myAreaCalc.getAreaOfCircle(3));