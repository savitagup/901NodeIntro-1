const events = require('events');
var eventEmitter = new events.EventEmitter();
eventEmitter.once("clock_in", () => {
    console.log('Clocking in....');
})
eventEmitter.once('work', ()=> {
    console.log("***********");
    console.log('Clocking in....');
    console.log('write Tests');
    console.log('code');
    console.log('Refactor');
})
eventEmitter.on('work', ()=> {
    console.log("***********")
    console.log('write Tests');
    console.log('code');
    console.log('Refactor');
    eventEmitter.emit('break');
})

var breakHandler = function checkEmails(){
    console.log('Check Emails');
}

eventEmitter.on('break',breakHandler);

//eventEmitter.emit("clock_in");
eventEmitter.emit('work');
eventEmitter.emit('work');


 