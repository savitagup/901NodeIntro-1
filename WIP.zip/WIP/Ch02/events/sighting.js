// Import events module
var events = require('events');

// Create an eventEmitter object
var eventEmitter = new events.EventEmitter();
let times =0;
// Create an event handler as follows
var sightHandler = function random() {
   let num = Math.floor(Math.random() * Math.floor(20));
    if(num === 11){
        console.log("11 is generated");
        times ++;

    }
}
 
// Bind the connection event with the handler

eventEmitter.on('generate', sightHandler);

// Fire the connection event 
for(let i=0;i<20;i++){
    eventEmitter.emit('generate' );
}
var genEmit = function genEmit(){
    eventEmitter.emit('generate' );
}


 let t2 = setInterval(genEmit,100);
  // Now clear the timer
  setTimeout(()=> {clearInterval(t2); console.log('cancelled timeout')}, 8000);

 
if(times === 0){
    console.log(`did not encounter 11 `);    
} else {
console.log(`11 is printed ${times} times`);
}