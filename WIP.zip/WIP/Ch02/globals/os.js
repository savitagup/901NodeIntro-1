const os = require('os');
console.log(os.totalmem());
console.log(os.freemem());