console.log('current file name ' , __filename);
console.log('current directory name ' , __dirname);
console.log('argument 0 ' , process.argv[0]);
console.log('argument 1 ' , process.argv[1]);

process.argv.forEach((val, index) => {
    console.log(`${index} : ${val}`);
});